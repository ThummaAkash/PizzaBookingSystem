package com.pizzabookingapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzabookingapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
