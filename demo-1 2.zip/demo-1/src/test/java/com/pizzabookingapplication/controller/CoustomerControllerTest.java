package com.pizzabookingapplication.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.BDDMockito.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pizzabookingapplication.dto.CustomerDTO;
import com.pizzabookingapplication.entity.Customer;
import com.pizzabookingapplication.service.ICustomerService;

//@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@WebMvcTest(CustomerController.class)
public class CoustomerControllerTest {

//	@Autowired
//	  private TestRestTemplate restTemplate;
//	  @LocalServerPort
//	  private int randomServerPort;
	
	@Autowired
	MockMvc mockMvc;
	@MockBean
	ICustomerService service;
	  
	@Autowired
	ObjectMapper object;
	  private CustomerDTO buildTestingCustomer() {
	        CustomerDTO customer = new CustomerDTO();
	        customer.setCustomerId(1);
	        customer.setCustomerName("ramesh");
	        customer.setCustomerEmail("ramesh@gmail.com");
	        customer.setCustomerAddress("mumbai");
	        customer.setCustomerMobile(9876543212L);
	        
	        return customer;
	    }
	  
	  @Test
	  void should_return_customers_list() throws Exception {
		  
		  CustomerDTO d = buildTestingCustomer();
		  when(service.viewAllCustomer()).thenReturn(List.of(d));
		  mockMvc.perform(get("/customer/all"))
		  .andExpect(status().isOk())
		  .andExpect(jsonPath("$[0].customerId", is(1)));
	      
	  
	  }
	  public Customer customerDtoToCustomer(CustomerDTO customerdto) {
			Customer cust=new Customer();
			cust.setCustomerId(customerdto.getCustomerId());
			cust.setCustomerName(customerdto.getCustomerName());
			cust.setCustomerMobile(customerdto.getCustomerMobile());
			cust.setCustomerEmail(customerdto.getCustomerEmail());
			cust.setCustomerAddress(customerdto.getCustomerAddress());
			return cust;
		}
	  
	  @Test
	    void should_return_customer() throws Exception {
		  CustomerDTO d = this.buildTestingCustomer();
		 
	        when(service.viewCustomerById(1)).thenReturn(d);
	 
	        mockMvc.perform(get("/customer/1"))
	            .andExpect(status().isOk())
	            .andExpect(jsonPath("$.customerId", is(1)));
	            
	    }
//	  @Test
//	    void should_add_customers()  throws Exception{
//		  CustomerDTO customer = buildTestingCustomer();
//
//	        given(service.registerCustomer(customer)).willReturn(customer);
//	        mockMvc.perform(post("/customer/register")
//	        .contentType(MediaType.APPLICATION_JSON)
//	        .content(object.writeValueAsString(customer)))
//	        .andExpect(status().isCreated());
//	    }
	  
	  @Test
	    void should_add_new_customer() throws Exception {
	        CustomerDTO dto = this.buildTestingCustomer();
	        when(service.registerCustomer(any(CustomerDTO.class))).thenReturn(dto);
	 
	        mockMvc.perform(post("/customer/register")
	            .contentType(MediaType.APPLICATION_JSON)
	            .content("{ \"customerName\": \"ramesh\", \"customerMobile\": \"9876543212\" ,\"customerEmail\":\"ramesh@gmail.com\" ,\"customerAddress\":\"mumbai\" }"))
	            .andExpect(status().isCreated())
	            .andExpect(jsonPath("$.customerName", is("ramesh")))
	            .andExpect(jsonPath("$.customerEmail", is("ramesh@gmail.com")));
	    }
	  
	  @Test
	    void should_remove_customer() throws Exception {
		  CustomerDTO d = this.buildTestingCustomer();
		  when(service.deleteById(d.getCustomerId())).thenReturn(d);
	        mockMvc.perform(delete("/customer/deletebyid/1"))
	            .andExpect(status().isOk());
	 
	    }


}
