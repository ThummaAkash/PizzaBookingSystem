package com.pizzabookingapplication.repository;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.pizzabookingapplication.entity.Customer;

/* The @DataJpaTest annotation is used to test JPA repositories inSpring Boot applications. 
It's a specialized test annotation that provides a minimal Spring context for testing 
the persistence layer. This annotation can be used in conjunction with other
testing annotations like @RunWith and @SpringBootTest  */

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class TestRepo {

	@Autowired
	CustomerRepository custoRepo;
	
	@Test
    public void findAll_should_return_coustomer_list() {
        // When
        List<Customer> customer = this.custoRepo.findAll();
        // Then
        Assertions.assertEquals(4, customer.size());
    }
	
	@Test
    void findById_should_return_customer() {
        // When
        Optional<Customer> customer = this.custoRepo.findById(2);
        // Then
        Assertions.assertTrue(customer.isPresent());
    }
	
	@Test
    void save_should_insert_new_customer() {
        // Given
        Customer newCustomer = new Customer();
        newCustomer.setCustomerName("prakash");
        newCustomer.setCustomerEmail("prakash@gmail.com");
        newCustomer.setCustomerAddress("hyderabad");
        newCustomer.setCustomerMobile(9876543210L);
        
        // When
        Customer persistedCustomer = this.custoRepo.save(newCustomer);
        // Then
        Assertions.assertNotNull(persistedCustomer);
        Assertions.assertEquals(5, persistedCustomer.getCustomerId());
    }
	
	@Test
    void save_should_update_existing_customer() {
        // Given
        Customer existingCustomer = new Customer();
        existingCustomer.setCustomerAddress("kolkata");
        existingCustomer.setCustomerMobile(8987654790L);
        existingCustomer.setCustomerEmail("akash05@gmail.com");
        existingCustomer.setCustomerName("akash");
       
        // When
        Customer updatedCustomer = this.custoRepo.save(existingCustomer);
        // Then
        Assertions.assertNotNull(updatedCustomer);
        Assertions.assertEquals("kolkata", updatedCustomer.getCustomerAddress());
        Assertions.assertEquals(8987654790L, updatedCustomer.getCustomerMobile());
        Assertions.assertEquals("akash05@gmail.com",updatedCustomer.getCustomerEmail());
        Assertions.assertEquals("akash",updatedCustomer.getCustomerName());
    }
	
	@Test
    void deleteById_should_delete_customer() {
        // When
        this.custoRepo.deleteById(2);
        Optional<Customer> customer = this.custoRepo.findById(2);
        // Then
        Assertions.assertFalse(customer.isPresent());
    }

}
