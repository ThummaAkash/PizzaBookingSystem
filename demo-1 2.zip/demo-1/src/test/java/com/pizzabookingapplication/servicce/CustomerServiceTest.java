package com.pizzabookingapplication.servicce;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.pizzabookingapplication.dto.CustomerDTO;
import com.pizzabookingapplication.entity.Customer;
import com.pizzabookingapplication.exception.CustomerException;
import com.pizzabookingapplication.mapper.CustomerMapper;
import com.pizzabookingapplication.repository.CustomerRepository;
import com.pizzabookingapplication.service.CustomerServiceImplimention;

//You can apply the extension by adding @ExtendWith(MockitoExtension.class) to the test class and annotating mocked fields with @Mock
@ExtendWith(MockitoExtension.class)
public class CustomerServiceTest {

	
	//@Mock allows us to create and inject a mock of CustomerloyeeRepository
			@Mock
		    private CustomerRepository customerRepository;
			
//			@InjectMocks is used to create an instance of our service EmployeeServiceImpl so that we can test it
		    @InjectMocks
			private CustomerServiceImplimention customerserviceimpl;
		    
		    
		    @Mock
		    CustomerMapper mapper;
		    
		    
		    private Customer buildTestingCustomer() {
		        Customer customer = new Customer();
		        customer.setCustomerId(1);
		        customer.setCustomerName("ramesh");
		        customer.setCustomerEmail("ramesh@gmail.com");
		        customer.setCustomerAddress("mumbai");
		        customer.setCustomerMobile(9876543212L);
		        
		        return customer;
		    }
		    
		    @Test
		    void findAll_should_return_customer_list() {
		        // Given
		        Customer customer = this.buildTestingCustomer();
		        // When
		        when(customerRepository.findAll()).thenReturn(List.of(customer));
		        List<Customer> customers = this.customerserviceimpl.viewAllCustomer()
		        		.stream().map(mapper::customerDtoToCustomer)
						.collect(Collectors.toList());;
		        // Then
		        Assertions.assertEquals(1, customers.size());
		        verify(this.customerRepository).findAll();
		    }
		    
		    @Test
		    void findById_should_return_customer() {
		        // Given
		        Customer customer = this.buildTestingCustomer();
		        customer.setCustomerId(1); // Set the customer ID to 1
		        // When
		        when(customerRepository.findById(1)).thenReturn(Optional.of(customer)); // Mock the repository to return the customer
		        Optional<Customer> returnedCustomer = customerRepository.findById(1);
		        // Then
		        assertTrue(returnedCustomer.isPresent()); // Ensure that the Optional is not empty
		        assertEquals(1, returnedCustomer.get().getCustomerId()); // Verify the customer ID
		        verify(customerRepository).findById(1); // Verify that findById was called with the correct ID
		    }
		    
		    public CustomerDTO customertoCustomerDTO(Customer customerDetails) {
	    		CustomerDTO dto = new CustomerDTO();
	    		dto.setCustomerId(customerDetails.getCustomerId());
	    		dto.setCustomerAddress(customerDetails.getCustomerAddress());
	    		dto.setCustomerEmail(customerDetails.getCustomerEmail());
	    		dto.setCustomerMobile(customerDetails.getCustomerMobile());
	    		dto.setCustomerName(customerDetails.getCustomerName());
	    		return dto;
	    	}

		    @Test
		    void save_should_insert_new_customer() {
		        // Given
		        Customer customer = this.buildTestingCustomer();
		        CustomerDTO dto=this.customertoCustomerDTO(customer);
		        System.out.println(customer);

		        // When
//		        
		        when(mapper.customerDtoToCustomer(dto)).thenReturn(customer);
		        when(customerRepository.save(customer)).thenReturn(customer);
		        this.customerserviceimpl.registerCustomer(dto);
		        System.out.println(customer);
		        // Then
		        
		        verify(this.customerRepository).save(customer);
		    }
		    
		    @Test
		    void deleteById_should_delete_customer()throws CustomerException {
		    	
		    	Customer customer = this.buildTestingCustomer();
		        // When
		    	 when(customerRepository.findById(1)).thenReturn(Optional.of(customer));
		        this.customerserviceimpl.deleteById(1);
		        // Then
		        verify(this.customerRepository).deleteById(1);
		    }


}
