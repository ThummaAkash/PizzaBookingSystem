package com.pizzabookingapplication.dto;
import com.pizzabookingapplication.entity.PizzaType;
import com.pizzabookingapplication.util.PizzaSize;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


public class PizzaDTO {
	private Integer pizzaId;
	private Integer pizzaTypeId; 
	private String pizzaName;
	private String pizzaDescription;  
	private Double pizzaCost;
	private PizzaSize pizzaSize;
	public Integer getPizzaId() {
		return pizzaId;
	}
	public void setPizzaId(Integer pizzaId) {
		this.pizzaId = pizzaId;
	}
	public Integer getPizzaTypeId() {
		return pizzaTypeId;
	}
	public void setPizzaTypeId(Integer pizzaTypeId) {
		this.pizzaTypeId = pizzaTypeId;
	}
	public String getPizzaName() {
		return pizzaName;
	}
	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}
	public String getPizzaDescription() {
		return pizzaDescription;
	}
	public void setPizzaDescription(String pizzaDescription) {
		this.pizzaDescription = pizzaDescription;
	}
	public Double getPizzaCost() {
		return pizzaCost;
	}
	public void setPizzaCost(Double pizzaCost) {
		this.pizzaCost = pizzaCost;
	}
	public PizzaSize getPizzaSize() {
		return pizzaSize;
	}
	public void setPizzaSize(PizzaSize pizzaSize) {
		this.pizzaSize = pizzaSize;
	}
	public PizzaDTO(Integer pizzaId, Integer pizzaTypeId, String pizzaName, String pizzaDescription, Double pizzaCost,
			PizzaSize pizzaSize) {
		super();
		this.pizzaId = pizzaId;
		this.pizzaTypeId = pizzaTypeId;
		this.pizzaName = pizzaName;
		this.pizzaDescription = pizzaDescription;
		this.pizzaCost = pizzaCost;
		this.pizzaSize = pizzaSize;
	}
	public PizzaDTO() {
		super();
	}
	
	
	
}
