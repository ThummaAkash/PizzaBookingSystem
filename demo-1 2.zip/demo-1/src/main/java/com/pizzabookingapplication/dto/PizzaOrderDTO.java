package com.pizzabookingapplication.dto;
import java.time.LocalDateTime;
import java.util.List;
import com.pizzabookingapplication.util.PizzaStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


public class PizzaOrderDTO {
	private Integer bookingOrderId;
	private LocalDateTime dateTimeOfOrder;
	private Integer quantity;
	private Double totalCost;
	private List<Integer> pizzaIdList;
	private Integer customerId;
	private PizzaStatus status;
	public Integer getBookingOrderId() {
		return bookingOrderId;
	}
	public void setBookingOrderId(Integer bookingOrderId) {
		this.bookingOrderId = bookingOrderId;
	}
	public LocalDateTime getDateTimeOfOrder() {
		return dateTimeOfOrder;
	}
	public void setDateTimeOfOrder(LocalDateTime dateTimeOfOrder) {
		this.dateTimeOfOrder = dateTimeOfOrder;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Double getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(Double totalCost) {
		this.totalCost = totalCost;
	}
	public List<Integer> getPizzaIdList() {
		return pizzaIdList;
	}
	public void setPizzaIdList(List<Integer> pizzaIdList) {
		this.pizzaIdList = pizzaIdList;
	}
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public PizzaStatus getStatus() {
		return status;
	}
	public void setStatus(PizzaStatus status) {
		this.status = status;
	}
	public PizzaOrderDTO(Integer bookingOrderId, LocalDateTime dateTimeOfOrder, Integer quantity, Double totalCost,
			List<Integer> pizzaIdList, Integer customerId, PizzaStatus status) {
		super();
		this.bookingOrderId = bookingOrderId;
		this.dateTimeOfOrder = dateTimeOfOrder;
		this.quantity = quantity;
		this.totalCost = totalCost;
		this.pizzaIdList = pizzaIdList;
		this.customerId = customerId;
		this.status = status;
	}
	public PizzaOrderDTO() {
		super();
	}
	
	
}
