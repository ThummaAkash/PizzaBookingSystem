package com.pizzabookingapplication.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.pizzabookingapplication.entity.Customer;
import com.pizzabookingapplication.entity.Pizza;
import com.pizzabookingapplication.entity.PizzaOrder;
import com.pizzabookingapplication.util.PizzaStatus;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


     
public class RequestPizzaOrderDTO {
	
	private Integer quantity;
	private List<Integer> pizzaIdList;
	private Integer customerId;
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public List<Integer> getPizzaIdList() {
		return pizzaIdList;
	}
	public void setPizzaIdList(List<Integer> pizzaIdList) {
		this.pizzaIdList = pizzaIdList;
	}
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public RequestPizzaOrderDTO(Integer quantity, List<Integer> pizzaIdList, Integer customerId) {
		super();
		this.quantity = quantity;
		this.pizzaIdList = pizzaIdList;
		this.customerId = customerId;
	}
	public RequestPizzaOrderDTO() {
		super();
	}
	
	
	
	
}
