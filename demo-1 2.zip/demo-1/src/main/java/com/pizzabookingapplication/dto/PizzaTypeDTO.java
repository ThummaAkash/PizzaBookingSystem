package com.pizzabookingapplication.dto;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


public class PizzaTypeDTO {
	private Integer pizzaTypeId;
	private String pizzaType;
	private List<Integer> toppingsIdList;
	public Integer getPizzaTypeId() {
		return pizzaTypeId;
	}
	public void setPizzaTypeId(Integer pizzaTypeId) {
		this.pizzaTypeId = pizzaTypeId;
	}
	public String getPizzaType() {
		return pizzaType;
	}
	public void setPizzaType(String pizzaType) {
		this.pizzaType = pizzaType;
	}
	public List<Integer> getToppingsIdList() {
		return toppingsIdList;
	}
	public void setToppingsIdList(List<Integer> toppingsIdList) {
		this.toppingsIdList = toppingsIdList;
	}
	public PizzaTypeDTO(Integer pizzaTypeId, String pizzaType, List<Integer> toppingsIdList) {
		super();
		this.pizzaTypeId = pizzaTypeId;
		this.pizzaType = pizzaType;
		this.toppingsIdList = toppingsIdList;
	}
	public PizzaTypeDTO() {
		super();
	}  
	
	
}
