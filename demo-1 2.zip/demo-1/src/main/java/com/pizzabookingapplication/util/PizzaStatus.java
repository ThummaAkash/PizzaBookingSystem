package com.pizzabookingapplication.util;


public enum PizzaStatus {

	BOOKED, CANCELLED, DELIVERED
}
