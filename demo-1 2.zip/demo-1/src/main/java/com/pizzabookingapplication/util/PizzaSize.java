package com.pizzabookingapplication.util;



public enum PizzaSize {
	SMALL , MEDIUM, LARGE;
}
