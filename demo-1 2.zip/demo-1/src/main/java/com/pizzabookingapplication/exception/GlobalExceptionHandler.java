package com.pizzabookingapplication.exception;

public class GlobalExceptionHandler {

}
