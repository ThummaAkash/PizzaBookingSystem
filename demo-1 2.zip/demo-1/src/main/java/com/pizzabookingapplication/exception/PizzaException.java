package com.pizzabookingapplication.exception;

public class PizzaException {
     
}
