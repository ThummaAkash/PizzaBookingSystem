package com.pizzabookingapplication.mapper;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.pizzabookingapplication.dto.PizzaTypeDTO;
import com.pizzabookingapplication.entity.PizzaType;
import com.pizzabookingapplication.entity.Toppings;
import com.pizzabookingapplication.repository.ToppingsRepository;

import lombok.AllArgsConstructor;

@Component

public class PizzaTypeMapper {
	ToppingsRepository toppingsRepo;
	
	public PizzaTypeMapper(ToppingsRepository toppingsRepo) {
		super();
		this.toppingsRepo = toppingsRepo;
	}
	public PizzaTypeDTO pizzaTypeToPizzaTypeDTO(PizzaType pizzaType) {
		PizzaTypeDTO dto=new PizzaTypeDTO();
		dto.setPizzaTypeId(pizzaType.getPizzaTypeId());
		dto.setPizzaType(pizzaType.getPizzaType());
		dto.setToppingsIdList(pizzaType.getToppingsList().stream()
				.map(Toppings::getToppingsId)
				.collect(Collectors.toList()));    
		return dto;
	}
	public PizzaType pizzaTypeDTOToPizzaType(PizzaTypeDTO dto) {
		 PizzaType pizzaType = new PizzaType();
		    pizzaType.setPizzaTypeId(dto.getPizzaTypeId());
		    pizzaType.setPizzaType(dto.getPizzaType());
		    List<Toppings> toppingsList = dto.getToppingsIdList().stream()
		            .map(toppingsId -> toppingsRepo.findById(toppingsId).orElse(null))
		            .filter(Objects::nonNull)
		            .collect(Collectors.toList());
		    pizzaType.setToppingsList(toppingsList);
		return pizzaType;
	}
}
