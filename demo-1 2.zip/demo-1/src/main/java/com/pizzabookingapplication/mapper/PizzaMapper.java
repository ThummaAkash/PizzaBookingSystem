
package com.pizzabookingapplication.mapper;

import org.springframework.stereotype.Component;

import com.pizzabookingapplication.dto.PizzaDTO;

import com.pizzabookingapplication.entity.Pizza;

import com.pizzabookingapplication.entity.PizzaType;

import com.pizzabookingapplication.repository.PizzaOrderRepository;

import com.pizzabookingapplication.repository.PizzaRepository;

import com.pizzabookingapplication.repository.PizzaTypeRepository;
 
import lombok.AllArgsConstructor;
 
@Component

public class PizzaMapper {

	PizzaRepository repo;

	PizzaOrderRepository porepo;

	PizzaTypeRepository pTypeRepo;
	

	public PizzaMapper(PizzaRepository repo, PizzaOrderRepository porepo, PizzaTypeRepository pTypeRepo) {
		super();
		this.repo = repo;
		this.porepo = porepo;
		this.pTypeRepo = pTypeRepo;
	}

	public  PizzaDTO PizzaToPizzaDTO(Pizza pizzaDetails) {

		PizzaDTO dto=new PizzaDTO();

		dto.setPizzaId(pizzaDetails.getPizzaId());
 
		int a=pizzaDetails.getPizzaType().getPizzaTypeId();

		dto.setPizzaTypeId(a);

		dto.setPizzaName(pizzaDetails.getPizzaName());

		dto.setPizzaCost(pizzaDetails.getPizzaCost());

		dto.setPizzaDescription(pizzaDetails.getPizzaDescription());  	

		dto.setPizzaSize(pizzaDetails.getPizzaSize());

		return dto;

	}

	public Pizza PizzaDTOToPizza(PizzaDTO pizzaDTO) {

		Pizza pizza=new Pizza();

		pizza.setPizzaId(pizzaDTO.getPizzaId());

//		pizza.setPizzaType(pizzaDTO.getPizzaType());

		int b=pizzaDTO.getPizzaTypeId();

		PizzaType pizzaType=pTypeRepo.findById(b).get();

		pizza.setPizzaType(pizzaType);

		pizza.setPizzaName(pizzaDTO.getPizzaName());

		pizza.setPizzaCost(pizzaDTO.getPizzaCost());

		pizza.setPizzaDescription(pizzaDTO.getPizzaDescription());

		pizza.setPizzaSize(pizzaDTO.getPizzaSize());

		return pizza;

	}

}
