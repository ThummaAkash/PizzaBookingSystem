package com.pizzabookingapplication.mapper;
 
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import org.springframework.stereotype.Component;
import com.pizzabookingapplication.dto.PizzaOrderDTO;
import com.pizzabookingapplication.dto.RequestPizzaOrderDTO;
import com.pizzabookingapplication.entity.Customer;
import com.pizzabookingapplication.entity.Pizza;
import com.pizzabookingapplication.entity.PizzaOrder;
import com.pizzabookingapplication.repository.CustomerRepository;
import com.pizzabookingapplication.repository.PizzaRepository;
import com.pizzabookingapplication.util.PizzaStatus;

import lombok.AllArgsConstructor;
 

@Component
public class PizzaOrderMapper {
	PizzaRepository repo;
	CustomerRepository customerRepo;
	
	public PizzaOrderMapper(PizzaRepository repo, CustomerRepository customerRepo) {
		super();
		this.repo = repo;
		this.customerRepo = customerRepo;
	}
	public PizzaOrderDTO pizzaOrderToPizzaOrderDTO(PizzaOrder pizzaOrder) {
		PizzaOrderDTO pizzaOrderDTO = new PizzaOrderDTO();
        pizzaOrderDTO.setBookingOrderId(pizzaOrder.getBookingOrderId());
        pizzaOrderDTO.setDateTimeOfOrder(pizzaOrder.getDateTimeOfOrder());
        pizzaOrderDTO.setQuantity(pizzaOrder.getQuantity());
        pizzaOrderDTO.setTotalCost(pizzaOrder.getTotalCost());
        pizzaOrderDTO.setPizzaIdList(
            pizzaOrder.getPizzaList().stream()
                .map(Pizza::getPizzaId)
                .collect(Collectors.toList())
        );
        pizzaOrderDTO.setCustomerId(pizzaOrder.getCustomer().getCustomerId());
        pizzaOrderDTO.setStatus(pizzaOrder.getStatus());
        return pizzaOrderDTO;
	}
	public  PizzaOrder pizzaOrderDTOToPizzaOrder(PizzaOrderDTO pizzaOrderDTO) {
		PizzaOrder pizzaOrder = new PizzaOrder();
	    pizzaOrder.setBookingOrderId(pizzaOrderDTO.getBookingOrderId());
	    pizzaOrder.setDateTimeOfOrder(pizzaOrderDTO.getDateTimeOfOrder());
	    pizzaOrder.setQuantity(pizzaOrderDTO.getQuantity());
	    pizzaOrder.setTotalCost(pizzaOrderDTO.getTotalCost());
 
	    // Fetch pizzas from the database based on the IDs in pizzaOrderDTO
	    List<Pizza> pizzas = pizzaOrderDTO.getPizzaIdList().stream()
	            .map(pizzaId -> {
	                return repo.findById(pizzaId).orElse(null);
	            })
	            .filter(Objects::nonNull)
	            .collect(Collectors.toList());
	    pizzaOrder.setPizzaList(pizzas);

	    Customer customer = customerRepo.findById(pizzaOrderDTO.getCustomerId()).get();
	    pizzaOrder.setCustomer(customer);
 
	    pizzaOrder.setStatus(pizzaOrderDTO.getStatus());
	    return pizzaOrder;
	}
	public  PizzaOrder pizzaOrderDTOToPizzaOrder(RequestPizzaOrderDTO pizzaOrderDTO) {
		
		PizzaOrder pizzaOrder = new PizzaOrder();
	    
	    pizzaOrder.setDateTimeOfOrder(LocalDateTime.now());
	    pizzaOrder.setQuantity(pizzaOrderDTO.getQuantity());
	    
	    
	    
 
	    // Fetch pizzas from the database based on the IDs in pizzaOrderDTO
	    List<Pizza> pizzas = pizzaOrderDTO.getPizzaIdList().stream()
	            .map(pizzaId -> {
	                return repo.findById(pizzaId).orElse(null);
	            })
	            .filter(Objects::nonNull)
	            .collect(Collectors.toList());
	    pizzaOrder.setPizzaList(pizzas);
	    
	    double d = 0;
	    for ( int  id :  pizzaOrderDTO.getPizzaIdList())
	    {
	    	Pizza p = repo.findById(id).get();
	    	d = d+p.getPizzaCost();
	    	
	    }
	    pizzaOrder.setTotalCost(d);

	    Customer customer = customerRepo.findById(pizzaOrderDTO.getCustomerId()).get();
	    pizzaOrder.setCustomer(customer);
 
	    pizzaOrder.setStatus(PizzaStatus.BOOKED);
	    return pizzaOrder;
	}
	}
 