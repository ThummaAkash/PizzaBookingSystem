package com.pizzabookingapplication.mapper;

import org.springframework.stereotype.Component;

import com.pizzabookingapplication.dto.CustomerDTO;
import com.pizzabookingapplication.entity.Customer;

import lombok.AllArgsConstructor;

@Component 

public class CustomerMapper {
	public CustomerDTO customertoCustomerDTO(Customer customerDetails) {
		CustomerDTO dto = new CustomerDTO();
		dto.setCustomerId(customerDetails.getCustomerId());
		dto.setCustomerAddress(customerDetails.getCustomerAddress());
		dto.setCustomerEmail(customerDetails.getCustomerEmail());
		dto.setCustomerMobile(customerDetails.getCustomerMobile());
		dto.setCustomerName(customerDetails.getCustomerName());
		return dto;
	}
	public Customer customerDtoToCustomer(CustomerDTO customerdto) {
		Customer cust=new Customer();
		cust.setCustomerId(customerdto.getCustomerId());
		cust.setCustomerName(customerdto.getCustomerName());
		cust.setCustomerMobile(customerdto.getCustomerMobile());
		cust.setCustomerEmail(customerdto.getCustomerEmail());
		cust.setCustomerAddress(customerdto.getCustomerAddress());
		return cust;
	}
}
