package com.pizzabookingapplication.mapper;

import org.springframework.stereotype.Component;

import com.pizzabookingapplication.dto.ToppingsDTO;
import com.pizzabookingapplication.entity.Toppings;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Component

public class ToppingsMapper {
	public ToppingsDTO ToppingsToToppingsDTO(Toppings toppings) {
		ToppingsDTO dto=new ToppingsDTO();
		dto.setToppingsId(toppings.getToppingsId());
		dto.setToppingsName(toppings.getToppingsName());
		dto.setPrice(toppings.getPrice());
		return dto;
	}
	public Toppings ToppingsDTOToToppings(ToppingsDTO toppingsDTO) {
		Toppings toppings=new Toppings();
		toppings.setToppingsId(toppingsDTO.getToppingsId());
		toppings.setToppingsName(toppingsDTO.getToppingsName());
		toppings.setPrice(toppingsDTO.getPrice());
		return toppings;
	}
}
