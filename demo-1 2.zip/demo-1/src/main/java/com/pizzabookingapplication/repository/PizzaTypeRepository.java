package com.pizzabookingapplication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.pizzabookingapplication.entity.Pizza;
import com.pizzabookingapplication.entity.PizzaType;

public interface PizzaTypeRepository extends JpaRepository<PizzaType,Integer>{
	@Query(
			"SELECT p FROM Pizza p JOIN p.pizzaType pt WHERE pt.pizzaType = :pizzaType"
          )
	List<Pizza> findByPizzaType(String pizzaType);
}
