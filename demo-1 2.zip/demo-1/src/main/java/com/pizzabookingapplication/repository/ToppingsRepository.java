package com.pizzabookingapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pizzabookingapplication.entity.Toppings;

public interface ToppingsRepository extends JpaRepository<Toppings,Integer>{

}
