package com.pizzabookingapplication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pizzabookingapplication.entity.Pizza;
import com.pizzabookingapplication.util.PizzaSize;

public interface PizzaRepository extends JpaRepository<Pizza,Integer>{
	
	 
	 List<Pizza> findByPizzaSize(PizzaSize valueOf);
	 List<Pizza> findByPizzaCostBetween(Double minPrice, Double maxPrice);
}
