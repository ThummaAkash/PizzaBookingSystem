package com.pizzabookingapplication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pizzabookingapplication.entity.PizzaOrder;
import com.pizzabookingapplication.util.PizzaStatus;

public interface PizzaOrderRepository extends JpaRepository<PizzaOrder, Integer>{
	List<PizzaOrder> findByStatus(PizzaStatus valueOf);
	 List<PizzaOrder> findByCustomer_CustomerId(Integer customerId);
}
