package com.pizzabookingapplication.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pizzabookingapplication.dto.CustomerDTO;
import com.pizzabookingapplication.service.ICustomerService;

import lombok.AllArgsConstructor;


@RestController
public class CustomerController {
	ICustomerService iCustomerService;
	
	 public CustomerController(ICustomerService iCustomerService) {
		super();
		this.iCustomerService = iCustomerService;
	}
	@PostMapping("/customer/register")
	    public ResponseEntity<CustomerDTO> registerCust(@RequestBody CustomerDTO customer) {
	        CustomerDTO registeredCustomer = iCustomerService.registerCustomer(customer);
	        if (registeredCustomer != null) {
	            return new ResponseEntity<>(registeredCustomer, HttpStatus.CREATED); // 201 Created
	        } else {
	            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR); // 500 Internal Server Error
	        }
	    }
	 @GetMapping("/customer/all")
	    public ResponseEntity<List<CustomerDTO>> viewAllCustomers() {
	        List<CustomerDTO> customers = iCustomerService.viewAllCustomer();
	        if (!customers.isEmpty()) {
	            return new ResponseEntity<>(customers, HttpStatus.OK); // 200 OK
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404 Not Found
	        }
	    }

	 @GetMapping("/customer/{Id}")
	    public ResponseEntity<CustomerDTO> viewCustomerByID(@PathVariable Integer Id) {
	        CustomerDTO customer = iCustomerService.viewCustomerById(Id);
	        if (customer != null) {
	            return new ResponseEntity<>(customer, HttpStatus.OK); // 200 OK
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404 Not Found
	        }
	    }
	 @GetMapping("/customer/ByCustomerMobile/{phoneNo}")
	    public ResponseEntity<CustomerDTO> viewCustomerByMobile(@PathVariable Long phoneNo) {
	        CustomerDTO customer = iCustomerService.viewCustomerByPhone(phoneNo);
	        if (customer != null) {
	            return new ResponseEntity<>(customer, HttpStatus.OK); // 200 OK
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404 Not Found
	        }
	    }
	@PutMapping("/customer/updatecustomer/{customer}")
	public ResponseEntity<CustomerDTO> updateCustomer(@PathVariable CustomerDTO customer){
			return new ResponseEntity<CustomerDTO>
			(iCustomerService.updateCustomer(customer),HttpStatus.OK);
	}
	
	 @DeleteMapping("/customer/deletebyid/{customerId}")
	    public ResponseEntity<CustomerDTO> deleteCustomerById(@PathVariable Integer customerId) {
	        CustomerDTO deletedCustomer = iCustomerService.deleteById(customerId);
	        if (deletedCustomer != null) {
	            return new ResponseEntity<>(deletedCustomer, HttpStatus.OK); // 200 OK
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404 Not Found
	        }
	    }
}
