package com.pizzabookingapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pizzabookingapplication.dto.PizzaDTO;
import com.pizzabookingapplication.dto.PizzaTypeDTO;
import com.pizzabookingapplication.dto.ToppingsDTO;
import com.pizzabookingapplication.service.IPizzaService;

import lombok.AllArgsConstructor;


@RestController
public class PizzaController {
	  @Autowired
	    IPizzaService iPizzaService;
	  
	 
	    @PostMapping("/pizzas")
	    public ResponseEntity<PizzaDTO> addPizza(@RequestBody PizzaDTO pizza) {
	        PizzaDTO addedPizza = iPizzaService.addPizza(pizza);
	        if (addedPizza != null) {
	            return new ResponseEntity<>(addedPizza, HttpStatus.CREATED); // 201 Created
	        } else {
	            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR); // 500 Internal Server Error
	        }
	    }
	    @PostMapping("/toppings")
	    public ResponseEntity<ToppingsDTO> addToppings(@RequestBody ToppingsDTO toppingsDTO) {
	        ToppingsDTO addedToppings = iPizzaService.addToppings(toppingsDTO);
	        if (addedToppings != null) {
	            return new ResponseEntity<>(addedToppings, HttpStatus.CREATED); // 201 Created
	        } else {
	            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR); // 500 Internal Server Error
	        }
	    }
	    @PostMapping("/pizzaTypes")
	    public ResponseEntity<PizzaTypeDTO> addPizzaType(@RequestBody PizzaTypeDTO pizzaTypeDTO) {
	        PizzaTypeDTO addedPizzaType = iPizzaService.addPizzaType(pizzaTypeDTO);
	        if (addedPizzaType != null) {
	            return new ResponseEntity<>(addedPizzaType, HttpStatus.CREATED); // 201 Created
	        } else {
	            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR); // 500 Internal Server Error
	        }
	    }
	    @PutMapping("/pizzas/update")
	    public ResponseEntity<PizzaDTO> updatePizza(@RequestBody PizzaDTO pizzaDTO) {
	        PizzaDTO updatedPizza = iPizzaService.updatePizza(pizzaDTO);
	        if (updatedPizza != null) {
	            return new ResponseEntity<>(updatedPizza, HttpStatus.OK); // 200 OK
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404 Not Found
	        }
	    }
	 
	 
//	    @GetMapping("/pizzas/{pizzaType}")
//	    public ResponseEntity<List<PizzaDTO>> viewPizzaByPizzaType(@PathVariable String pizzaType) {
//	        List<PizzaDTO> pizzas = iPizzaService.(pizzaType);
//	        if (!pizzas.isEmpty()) {
//	            return new ResponseEntity<>(pizzas, HttpStatus.OK); // 200 OK
//	        } else {
//	            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404 Not Found
//	        }
//	    }
	    @GetMapping("/pizzas")
	    public ResponseEntity<List<PizzaDTO>> viewPizzaByPizzaSize(@RequestParam String pizzaSize) {
	        List<PizzaDTO> pizzas = iPizzaService.viewPizzaByPizzaSize(pizzaSize);
	        if (!pizzas.isEmpty()) {
	            return new ResponseEntity<>(pizzas, HttpStatus.OK); // 200 OK
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404 Not Found
	        }
	    }
	    @GetMapping("/pizzas/all")
	    public ResponseEntity<List<PizzaDTO>> viewAllPizza() {
	        List<PizzaDTO> pizzas = iPizzaService.viewAllPizza();
	        if (!pizzas.isEmpty()) {
	            return new ResponseEntity<>(pizzas, HttpStatus.OK); // 200 OK
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404 Not Found
	        }
	    }
	    @GetMapping("/toppings/all")
	    public ResponseEntity<List<ToppingsDTO>> viewAllToppings() {
	        List<ToppingsDTO> toppings = iPizzaService.viewToppings();
	        if (!toppings.isEmpty()) {
	            return new ResponseEntity<>(toppings, HttpStatus.OK); // 200 OK
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404 Not Found
	        }
	    }
	    @GetMapping("/toppings/{toppingId}")
	    public ResponseEntity<ToppingsDTO> viewToppingById(@PathVariable Integer toppingId) {
	        ToppingsDTO topping = iPizzaService.viewToppingByID(toppingId);
	        if (topping != null) {
	            return new ResponseEntity<>(topping, HttpStatus.OK); // 200 OK
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404 Not Found
	        }
	    }
	    @GetMapping("/pizzatypes/{pizzaTypeId}")
	    public ResponseEntity<PizzaTypeDTO> viewPizzaTypeById(@PathVariable Integer pizzaTypeId) {
	        PizzaTypeDTO pizzaType = iPizzaService.viewPizzaTypeById(pizzaTypeId);
	        if (pizzaType != null) {
	            return new ResponseEntity<>(pizzaType, HttpStatus.OK); // 200 OK
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404 Not Found
	        }
	    }
	    @GetMapping("/pizzatypes")
	    public ResponseEntity<List<PizzaTypeDTO>> viewAllPizzaTypes() {
	        List<PizzaTypeDTO> pizzaTypes = iPizzaService.viewAllPizzaTypes();
	        if (!pizzaTypes.isEmpty()) {
	            return new ResponseEntity<>(pizzaTypes, HttpStatus.OK); // 200 OK
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404 Not Found
	        }
	    }
	    @GetMapping("/pizzas/price")
	    public ResponseEntity<List<PizzaDTO>> viewPizzaByPriceRange(
	            @RequestParam("minPrice") Double minPrice,
	            @RequestParam("maxPrice") Double maxPrice) {
	        List<PizzaDTO> pizzas = iPizzaService.viewPizzaByPrice(minPrice, maxPrice);
	        if (!pizzas.isEmpty()) {
	            return new ResponseEntity<>(pizzas, HttpStatus.OK); // 200 OK
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404 Not Found
	        }
	    }
}
