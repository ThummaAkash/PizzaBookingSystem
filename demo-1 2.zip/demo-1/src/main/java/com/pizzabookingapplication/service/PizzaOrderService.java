package com.pizzabookingapplication.service;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import com.pizzabookingapplication.dto.PizzaOrderDTO;
import com.pizzabookingapplication.dto.RequestPizzaOrderDTO;
import com.pizzabookingapplication.entity.PizzaOrder;
import com.pizzabookingapplication.exception.CustomerException;
import com.pizzabookingapplication.mapper.PizzaOrderMapper;
import com.pizzabookingapplication.repository.PizzaOrderRepository;
import com.pizzabookingapplication.util.PizzaStatus;
import lombok.AllArgsConstructor;

                                
@Service

public class PizzaOrderService implements IPizzaOrderService{
	PizzaOrderMapper pizzaOrderMapper;
	PizzaOrderRepository pizzaOrderRepo;
	CustomerServiceImplimention customerServiceImplimentation;
	


	public PizzaOrderService(PizzaOrderMapper pizzaOrderMapper, PizzaOrderRepository pizzaOrderRepo,
			CustomerServiceImplimention customerServiceImplimentation) {
		super();
		this.pizzaOrderMapper = pizzaOrderMapper;
		this.pizzaOrderRepo = pizzaOrderRepo;
		this.customerServiceImplimentation = customerServiceImplimentation;
	}
	@Override
	public PizzaOrderDTO viewPizzaOrderById(Integer pizzaOrderId) {
		// TODO Auto-generated method stub
		// Retrieve pizza order by ID
        PizzaOrder pizzaOrder = pizzaOrderRepo.findById(pizzaOrderId)
                .orElseThrow(() -> new CustomerException("Pizza order not found for ID: " + pizzaOrderId));
        // Mapping entity to DTO and returning
        return pizzaOrderMapper.pizzaOrderToPizzaOrderDTO(pizzaOrder);  
	}
	@Override
	public List<PizzaOrderDTO> viewPizzaOrderByCustomerId(Integer customerId) {
		// TODO Auto-generated method stub
		List<PizzaOrder> pizzaOrders = pizzaOrderRepo.findByCustomer_CustomerId(customerId);
        return pizzaOrders.stream()
                .map(pizzaOrderMapper::pizzaOrderToPizzaOrderDTO)
                .collect(Collectors.toList());
	}
 
	@Override
	public PizzaOrderDTO cancelPizzaOrder(Integer pizzaId) {
		// TODO Auto-generated method stub
		 // Checking if the pizza order exists
        PizzaOrder existingPizzaOrder = pizzaOrderRepo.findById(pizzaId)
                .orElseThrow(() -> new RuntimeException("Pizza order not found for ID: " + pizzaId));
 
        // Updating status to CANCELLED
        existingPizzaOrder.setStatus(PizzaStatus.CANCELLED);
 
        // Saving updated pizza order
       // PizzaOrder cancelledPizzaOrder = pizzaOrderRepo.save(existingPizzaOrder);
        // Mapping entity to DTO and returning
        return pizzaOrderMapper.pizzaOrderToPizzaOrderDTO(existingPizzaOrder);
	}
 
 
	@Override
	public List<PizzaOrderDTO> viewAllPizzaOrders() {
		// TODO Auto-generated method stub
		// Retrieve all pizza orders
		List<PizzaOrder> pizzaOrdersList=pizzaOrderRepo.findAll();
		// Mapping entities to DTOs and returning
		return pizzaOrdersList.stream()
                .map(pizzaOrderMapper::pizzaOrderToPizzaOrderDTO)
                .collect(Collectors.toList());
	}
	@Override
	public List<PizzaOrderDTO> viewPizzaOrderByStatus(String status) {
		// TODO Auto-generated method stub
		// Retrieve pizza orders by status
        List<PizzaOrder> pizzaOrders = pizzaOrderRepo.findByStatus(PizzaStatus.valueOf(status));
        // Mapping entities to DTOs and returning
        return pizzaOrders.stream()
                .map(pizzaOrderMapper::pizzaOrderToPizzaOrderDTO)
                .collect(Collectors.toList());
	}
	@Override
	public PizzaOrderDTO bookPizzaOrder(RequestPizzaOrderDTO order) {
		// TODO Auto-generated method stub
		// Mapping DTO to entity
        PizzaOrder pizzaOrder = pizzaOrderMapper.pizzaOrderDTOToPizzaOrder(order);
        
        // Save pizza order
        PizzaOrder savedPizzaOrder = pizzaOrderRepo.save(pizzaOrder);
        // Mapping entity to DTO and returning
        return pizzaOrderMapper.pizzaOrderToPizzaOrderDTO(savedPizzaOrder);
	}
	@Override
	public PizzaOrderDTO updatepizzaOrder(RequestPizzaOrderDTO pizzaOrder) {
		// TODO Auto-generated method stub
		PizzaOrder piOrder=pizzaOrderMapper.pizzaOrderDTOToPizzaOrder(pizzaOrder);
		Integer bookingOrderId = piOrder.getBookingOrderId();
        // Checking if the pizza order exists
        PizzaOrder existingPizzaOrder = pizzaOrderRepo.findById(bookingOrderId)
                .orElseThrow(() -> new RuntimeException("Pizza order not found for ID: " + bookingOrderId));
 
        // Updating fields
      
        existingPizzaOrder.setQuantity(pizzaOrder.getQuantity());
 
        //Saving updated pizza order
        PizzaOrder updatedPizzaOrder = pizzaOrderRepo.save(existingPizzaOrder);
        // Mapping entity to DTO and returning
        return pizzaOrderMapper.pizzaOrderToPizzaOrderDTO(updatedPizzaOrder);
	}	
}
