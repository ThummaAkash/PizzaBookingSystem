package com.pizzabookingapplication.service;

import java.util.List;

import com.pizzabookingapplication.dto.PizzaDTO;
import com.pizzabookingapplication.dto.PizzaTypeDTO;
import com.pizzabookingapplication.dto.ToppingsDTO;

public interface IPizzaService {
	PizzaDTO addPizza(PizzaDTO pizza);

	ToppingsDTO addToppings(ToppingsDTO toppings);

	PizzaTypeDTO addPizzaType(PizzaTypeDTO pizzaType);

	PizzaDTO updatePizza(PizzaDTO pizza);

	PizzaDTO viewPizzaById(Integer pizzaId);

	List<PizzaDTO> viewPizzaByPizzaSize(String pizzaSize);

	List<PizzaDTO> viewPizzaByPrice(Double minPrice, Double maxPrice);

	List<PizzaDTO> viewAllPizza();
        
	List<ToppingsDTO> viewToppings();

	ToppingsDTO viewToppingByID(Integer toppingsID);

	PizzaTypeDTO viewPizzaTypeById(Integer pizzaTypeId);    

	List<PizzaTypeDTO> viewAllPizzaTypes();
}
