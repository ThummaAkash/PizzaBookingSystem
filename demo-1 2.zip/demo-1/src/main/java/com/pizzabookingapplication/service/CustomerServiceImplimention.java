package com.pizzabookingapplication.service;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.pizzabookingapplication.dto.CustomerDTO;
import com.pizzabookingapplication.entity.Customer;
import com.pizzabookingapplication.exception.CustomerException;
import com.pizzabookingapplication.mapper.CustomerMapper;
import com.pizzabookingapplication.repository.CustomerRepository;

import lombok.AllArgsConstructor;


@Service   
public class CustomerServiceImplimention implements ICustomerService{
	CustomerRepository customerRepo;
	CustomerMapper customermapper;
	
	public CustomerServiceImplimention(CustomerRepository customerRepo, CustomerMapper customermapper) {
		super();
		this.customerRepo = customerRepo;
		this.customermapper = customermapper;
	}
	@Override 
	public CustomerDTO viewCustomerById(Integer customerId) throws CustomerException {
		// TODO Auto-generated method stub
		if (customerId == null) {
            throw new IllegalArgumentException("Customer ID cannot be null");
        }
		Customer dto= customerRepo.findById(customerId)
				.orElseThrow(()->new CustomerException("Customer Id is Not Found"));
		return customermapper.customertoCustomerDTO(dto);
	}
	@Override
	public List<CustomerDTO> viewAllCustomer() {
		// TODO Auto-generated method stub
		List<Customer> customers=customerRepo.findAll();
		if(customers.isEmpty()) {
			throw new CustomerException("No customer avaialable");
		}
		return customers.stream()
				.map(customermapper::customertoCustomerDTO)
				.collect(Collectors.toList());

	} 
	@Override
	public CustomerDTO registerCustomer(CustomerDTO customerDTO) {
		// TODO Auto-generated method stub
//		 if (customerDTO == null) {
//		            throw new CustomerException("Customer data is not complete");
//		        }  
		      Customer  customer=customermapper.customerDtoToCustomer(customerDTO);
		        return customermapper.customertoCustomerDTO(customerRepo.save(customer));
	}
 
	@Override
	public CustomerDTO updateCustomer(CustomerDTO customer) {
		Integer customerId=customer.getCustomerId();
		CustomerDTO existingCustomerDTO=viewCustomerById(customerId);
		// Check if the customer exists
	    if (existingCustomerDTO == null) {
	        throw new CustomerException("Customer not found for ID: " + customerId);
	    }
 
	    // Update fields chosen by the customer
	    
	        existingCustomerDTO.setCustomerName(customer.getCustomerName());
	        existingCustomerDTO.setCustomerMobile(customer.getCustomerMobile());
	        existingCustomerDTO.setCustomerEmail(customer.getCustomerEmail());
	        existingCustomerDTO.setCustomerAddress(customer.getCustomerAddress());
	    // Add more fields to update as needed
		return existingCustomerDTO;
	}
 
	@Override
	public CustomerDTO viewCustomerByPhone(Long phoneNo) {
		if (phoneNo == null) {
            throw new CustomerException("Phone number cannot be null");
        }
 
		Customer foundCustomer=customerRepo.findByCustomerMobile(phoneNo);
		if (foundCustomer == null){
	            throw new RuntimeException("Customer not found for phone number: " + phoneNo);
	        }
	        // If the customer is found, map it to CustomerDTO and return
	        return customermapper.customertoCustomerDTO(foundCustomer);

	}
	@Override
	public CustomerDTO deleteById(Integer customerId) {
	    // Check if the customerId is null
	    if (customerId == null) {
	        throw new CustomerException("Customer ID cannot be null");
	    }

	    // Check if the customer exists
	    Customer existingCustomer = customerRepo.findById(customerId)
	            .orElseThrow(() -> new CustomerException("Customer not found for ID: " + customerId));

	    // Delete the customer from the repository
	    customerRepo.deleteById(customerId);

	    // Map the deleted customer to CustomerDTO and return
	    return customermapper.customertoCustomerDTO(existingCustomer);
	}
 
}
