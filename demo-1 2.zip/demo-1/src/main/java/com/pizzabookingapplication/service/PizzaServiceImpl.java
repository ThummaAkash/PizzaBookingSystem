package com.pizzabookingapplication.service;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.pizzabookingapplication.dto.PizzaDTO;
import com.pizzabookingapplication.dto.PizzaTypeDTO;
import com.pizzabookingapplication.dto.ToppingsDTO;
import com.pizzabookingapplication.entity.Pizza;
import com.pizzabookingapplication.entity.PizzaType;
import com.pizzabookingapplication.entity.Toppings;
import com.pizzabookingapplication.mapper.PizzaMapper;
import com.pizzabookingapplication.mapper.PizzaTypeMapper;
import com.pizzabookingapplication.mapper.ToppingsMapper;
import com.pizzabookingapplication.repository.PizzaRepository;
import com.pizzabookingapplication.repository.PizzaTypeRepository;
import com.pizzabookingapplication.repository.ToppingsRepository;
import com.pizzabookingapplication.util.PizzaSize;
 
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
 

@Service
public class PizzaServiceImpl implements IPizzaService {
	PizzaRepository pizzaRepo;
	PizzaMapper pizzaMap;
	PizzaTypeMapper pizzaTypeMapper;
	PizzaTypeRepository pizzaTypeRepo;
	ToppingsRepository topRepo;
	ToppingsMapper topMapper;
	

	public PizzaServiceImpl(PizzaRepository pizzaRepo, PizzaMapper pizzaMap, PizzaTypeMapper pizzaTypeMapper,
			PizzaTypeRepository pizzaTypeRepo, ToppingsRepository topRepo, ToppingsMapper topMapper) {
		super();
		this.pizzaRepo = pizzaRepo;
		this.pizzaMap = pizzaMap;
		this.pizzaTypeMapper = pizzaTypeMapper;
		this.pizzaTypeRepo = pizzaTypeRepo;
		this.topRepo = topRepo;
		this.topMapper = topMapper;
	}

	@Override
	public PizzaDTO addPizza(PizzaDTO pizza) {
		// TODO Auto-generated method stub
		return pizzaMap.PizzaToPizzaDTO(pizzaRepo.save(pizzaMap.PizzaDTOToPizza(pizza)));
	}
 
	@Override
	public ToppingsDTO addToppings(ToppingsDTO toppings) {
		// TODO Auto-generated method stub
		if(toppings==null) {
			throw new IllegalArgumentException("Toppings Data is not complete");
		}
		Toppings topping=topMapper.ToppingsDTOToToppings(toppings);
		return topMapper.ToppingsToToppingsDTO(topRepo.save(topping));   
	}
 
	@Override
	public PizzaTypeDTO addPizzaType(PizzaTypeDTO pizzaType) {
		// TODO Auto-generated method stub
		PizzaType pType=pizzaTypeRepo.save(pizzaTypeMapper.pizzaTypeDTOToPizzaType(pizzaType));
		return pizzaTypeMapper.pizzaTypeToPizzaTypeDTO(pType);   
	}
 
	@Override
	public PizzaDTO updatePizza(PizzaDTO pizza) {
		// TODO Auto-generated method stub
		Pizza updatedPizza = pizzaRepo.findById(pizza.getPizzaId()).orElse(null); 
	    if (updatedPizza != null) {
	        // Update pizza attributes based on pizzaDTO
	    	updatedPizza.setPizzaName(pizza.getPizzaName());
	    	updatedPizza.setPizzaSize(pizza.getPizzaSize());
//	    	updatedPizza.setPizzaType(pizza.getPizzaTypeId().);
	    	updatedPizza.setPizzaCost(pizza.getPizzaCost());
	    	updatedPizza.setPizzaDescription(pizza.getPizzaDescription());
	        // Save the updated pizza
	    	updatedPizza = pizzaRepo.save(updatedPizza);
	        return pizzaMap.PizzaToPizzaDTO(updatedPizza);
	    } else {
	        // Pizza with given ID not found
	        throw new IllegalArgumentException("Pizza not found with ID: " + pizza.getPizzaId());
	    }
	}
 
	@Override
	public PizzaDTO viewPizzaById(Integer pizzaId) {
		// TODO Auto-generated method stub
		Pizza pizza=pizzaRepo.findById(pizzaId).get();
		if(pizza!=null)
		return pizzaMap.PizzaToPizzaDTO(pizza);   
		else 
			   throw new IllegalArgumentException("Pizza not found with ID: " + pizzaId);
	}
 
	@Override
	public List<PizzaDTO> viewPizzaByPizzaSize(String pizzaSize) {
		List<Pizza> pizzas =pizzaRepo.findByPizzaSize(PizzaSize.valueOf(pizzaSize));
		List<PizzaDTO> pizzaDTOs=new ArrayList<>();
		for (Pizza pizza : pizzas) {
	        pizzaDTOs.add(pizzaMap.PizzaToPizzaDTO(pizza));
	    }
		return pizzaDTOs;
 
	}
 
	@Override
	public List<PizzaDTO> viewPizzaByPrice(Double minPrice, Double maxPrice) {
		// TODO Auto-generated method stub
		return null;
	}
 
	@Override
	public List<PizzaDTO> viewAllPizza() {
		// TODO Auto-generated method stub
		List<Pizza> pizzas =pizzaRepo.findAll();
		List<PizzaDTO> pizzaDTOs=new ArrayList<>();
		for (Pizza pizza : pizzas) {
	        pizzaDTOs.add(pizzaMap.PizzaToPizzaDTO(pizza));
	    }
		return pizzaDTOs;
	}
 
	@Override
	public List<ToppingsDTO> viewToppings() {
		// TODO Auto-generated method stub
		List<Toppings>toppingsList=topRepo.findAll();
		List<ToppingsDTO> toppingsDTO=new ArrayList<>();
		for (Toppings topping: toppingsList) {
			toppingsDTO.add(topMapper.ToppingsToToppingsDTO(topping));
	    }
		return toppingsDTO;
	}
 
	@Override
	public ToppingsDTO viewToppingByID(Integer toppingsID) {
		// TODO Auto-generated method stub
		Toppings toppings=topRepo.findById(toppingsID).get();
		if(toppings!=null)
		return topMapper.ToppingsToToppingsDTO(toppings);   
		else
			  throw new IllegalArgumentException("Pizza not found with ID: " + toppingsID);
	}
	@Override
	public List<PizzaTypeDTO> viewAllPizzaTypes() {
		// TODO Auto-generated method stub
		List<PizzaType> pTypeList=pizzaTypeRepo.findAll();
		List<PizzaTypeDTO> pizzaTypeDTOs = new ArrayList<>();
	    for (PizzaType pizzaType : pTypeList) {
	        pizzaTypeDTOs.add(pizzaTypeMapper.pizzaTypeToPizzaTypeDTO(pizzaType));
	    }
	    return pizzaTypeDTOs;
	}
 
	@Override
	public PizzaTypeDTO viewPizzaTypeById(Integer pizzaTypeId) {
		// TODO Auto-generated method stub
		PizzaType pType=pizzaTypeRepo.findById(pizzaTypeId).get();
		if(pType!=null)
		return pizzaTypeMapper.pizzaTypeToPizzaTypeDTO(pType);  
		else
			throw new IllegalArgumentException("Pizza not found with ID: " + pizzaTypeId);
	}
 
}