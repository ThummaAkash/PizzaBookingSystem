package com.pizzabookingapplication.service;
import java.util.List;

import com.pizzabookingapplication.dto.PizzaOrderDTO;
import com.pizzabookingapplication.dto.RequestPizzaOrderDTO;

public interface IPizzaOrderService {
	PizzaOrderDTO bookPizzaOrder(RequestPizzaOrderDTO order);

	PizzaOrderDTO updatepizzaOrder(RequestPizzaOrderDTO pizzaOrder);

	PizzaOrderDTO cancelPizzaOrder(Integer pizzaId);

	PizzaOrderDTO viewPizzaOrderById(Integer pizzaOrderId);
	
	List<PizzaOrderDTO> viewAllPizzaOrders();
	
	List<PizzaOrderDTO> viewPizzaOrderByCustomerId(Integer customerId);
	
	List<PizzaOrderDTO> viewPizzaOrderByStatus(String status);

}
