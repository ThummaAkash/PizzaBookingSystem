package com.pizzabookingapplication.entity;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.pizzabookingapplication.util.PizzaSize;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
public class Pizza {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer pizzaId;
	
	@OneToOne(cascade =CascadeType.ALL)
	@JoinColumn(name="pizzaType_id")
	private PizzaType pizzaType;
	
	@Column(nullable=false)  
	private String pizzaName;
	@Column(nullable=false)  
	private String pizzaDescription;
	// Base Price
	@Column(nullable=false)  
	private Double pizzaCost;
	@Column(nullable=false)  
	private PizzaSize pizzaSize;
	
	@JsonManagedReference
	@ManyToMany(mappedBy="pizzaList")
	private List<PizzaOrder> pizzaOrder;
	
	public void addOrder ( PizzaOrder po)
	{
		if(pizzaOrder == null)
			pizzaOrder = new ArrayList<>();
		pizzaOrder.add(po);
	}

	public Integer getPizzaId() {
		return pizzaId;
	}

	public void setPizzaId(Integer pizzaId) {
		this.pizzaId = pizzaId;
	}

	public PizzaType getPizzaType() {
		return pizzaType;
	}

	public void setPizzaType(PizzaType pizzaType) {
		this.pizzaType = pizzaType;
	}

	public String getPizzaName() {
		return pizzaName;
	}

	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}

	public String getPizzaDescription() {
		return pizzaDescription;
	}

	public void setPizzaDescription(String pizzaDescription) {
		this.pizzaDescription = pizzaDescription;
	}

	public Double getPizzaCost() {
		return pizzaCost;
	}

	public void setPizzaCost(Double pizzaCost) {
		this.pizzaCost = pizzaCost;
	}

	public PizzaSize getPizzaSize() {
		return pizzaSize;
	}

	public void setPizzaSize(PizzaSize pizzaSize) {
		this.pizzaSize = pizzaSize;
	}

	public List<PizzaOrder> getPizzaOrder() {
		return pizzaOrder;
	}

	public void setPizzaOrder(List<PizzaOrder> pizzaOrder) {
		this.pizzaOrder = pizzaOrder;
	}

	public Pizza(Integer pizzaId, PizzaType pizzaType, String pizzaName, String pizzaDescription, Double pizzaCost,
			PizzaSize pizzaSize, List<PizzaOrder> pizzaOrder) {
		super();
		this.pizzaId = pizzaId;
		this.pizzaType = pizzaType;
		this.pizzaName = pizzaName;
		this.pizzaDescription = pizzaDescription;
		this.pizzaCost = pizzaCost;
		this.pizzaSize = pizzaSize;
		this.pizzaOrder = pizzaOrder;
	}

	public Pizza() {
		super();
	}
	
	
	
}
