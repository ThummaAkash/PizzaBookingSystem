package com.pizzabookingapplication.entity;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.pizzabookingapplication.util.PizzaStatus;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
       
public class PizzaOrder {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer bookingOrderId;
	@Column(nullable=false)
	private LocalDateTime dateTimeOfOrder;
	@Column(nullable=false)
	private Integer quantity;
	@Column(nullable=false)
	private Double totalCost;
	
	@JsonBackReference
	@ManyToMany(fetch = FetchType.EAGER,cascade= {CascadeType.PERSIST,CascadeType.MERGE,
			CascadeType.DETACH,CascadeType.REFRESH})
	@JoinTable(
            name = "pizzaOrder_pizza",
            joinColumns = @JoinColumn(name = "pizzaOrder_id"),
            inverseJoinColumns = @JoinColumn(name = "pizza_id")
    )
	private List<Pizza> pizzaList;
	public void addPizza ( Pizza p)
	{
		if ( pizzaList == null)
			pizzaList = new ArrayList<>();
		pizzaList.add(p);
	}
  
	
	@ManyToOne
    @JoinColumn(name = "customer_id")
	private Customer customer;
	
	@Enumerated(EnumType.STRING)
    private  PizzaStatus status;
	public Integer getBookingOrderId() {
		return bookingOrderId;
	}

	public void setBookingOrderId(Integer bookingOrderId) {
		this.bookingOrderId = bookingOrderId;
	}

	public LocalDateTime getDateTimeOfOrder() {
		return dateTimeOfOrder;
	}

	public void setDateTimeOfOrder(LocalDateTime dateTimeOfOrder) {
		this.dateTimeOfOrder = dateTimeOfOrder;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(Double totalCost) {
		this.totalCost = totalCost;
	}

	public List<Pizza> getPizzaList() {
		return pizzaList;
	}

	public void setPizzaList(List<Pizza> pizzaList) {
		this.pizzaList = pizzaList;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public PizzaStatus getStatus() {
		return status;
	}

	public void setStatus(PizzaStatus status) {
		this.status = status;
	}

	public PizzaOrder(Integer bookingOrderId, LocalDateTime dateTimeOfOrder, Integer quantity, Double totalCost,
			List<Pizza> pizzaList, Customer customer, PizzaStatus status) {
		super();
		this.bookingOrderId = bookingOrderId;
		this.dateTimeOfOrder = dateTimeOfOrder;
		this.quantity = quantity;
		this.totalCost = totalCost;
		this.pizzaList = pizzaList;
		this.customer = customer;
		this.status = status;
	}

	public PizzaOrder() {
		super();
	}
	
	
}
