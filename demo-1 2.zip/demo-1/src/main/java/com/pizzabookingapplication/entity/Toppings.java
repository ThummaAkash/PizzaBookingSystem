package com.pizzabookingapplication.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity

public class Toppings {
	
	@Id   
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer toppingsId;
	
	@Column(nullable=false,length=100)
	private String toppingsName;
	@Column(nullable=false,length=100)
	private Double price;
	
	@JsonManagedReference
	@ManyToMany(mappedBy="toppingsList")
	private List<PizzaType> pizzatype;

	public Integer getToppingsId() {
		return toppingsId;
	}

	public void setToppingsId(Integer toppingsId) {
		this.toppingsId = toppingsId;
	}

	public String getToppingsName() {
		return toppingsName;
	}

	public void setToppingsName(String toppingsName) {
		this.toppingsName = toppingsName;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public List<PizzaType> getPizzatype() {
		return pizzatype;
	}

	public void setPizzatype(List<PizzaType> pizzatype) {
		this.pizzatype = pizzatype;
	}

	public Toppings(Integer toppingsId, String toppingsName, Double price, List<PizzaType> pizzatype) {
		super();
		this.toppingsId = toppingsId;
		this.toppingsName = toppingsName;
		this.price = price;
		this.pizzatype = pizzatype;
	}

	public Toppings() {
		super();
	}
	
	
	
}
