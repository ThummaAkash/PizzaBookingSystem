package com.pizzabookingapplication.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;


@Entity

public class Customer{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer customerId;
	@Column(nullable=false)
	private String customerName;
	@Column(nullable=false)
	private Long customerMobile; 
	@Column(nullable=false)
	private String customerEmail;
	@Column(nullable=false)
	private String customerAddress;
	
	
	@OneToMany(mappedBy="customer")   
	List<PizzaOrder> pizzaOrderList;
	public void addPizzaOrder(PizzaOrder pizzaOrder) {
		if(pizzaOrderList==null) {
			 pizzaOrderList=new ArrayList<>();
		}
		pizzaOrderList.add(pizzaOrder);
	}
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Long getCustomerMobile() {
		return customerMobile;
	}
	public void setCustomerMobile(Long customerMobile) {
		this.customerMobile = customerMobile;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public List<PizzaOrder> getPizzaOrderList() {
		return pizzaOrderList;
	}
	public void setPizzaOrderList(List<PizzaOrder> pizzaOrderList) {
		this.pizzaOrderList = pizzaOrderList;
	}
	
	
}
